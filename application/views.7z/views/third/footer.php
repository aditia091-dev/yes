


					</div>

					<!--=======  End of testmonial slider container  =======-->
				</div>
			</div>
		</div>
	</div>

	<!--=====  End of single item testimonial area  ======-->


	<!--=============================================
	=            instagram slider area         =
	=============================================-->

	<div class="instagram-slider-area mb-100">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-8 order-2 order-lg-1">
					<!--=============================================
					=            instagram image slider         =
					=============================================-->

					<div class="instagram-image-slider-area">
						<!--=======  instagram image container  =======-->

						<div class="instagram-image-slider-container">
							<div class="instagram-feed-thumb">
								<div id="instagramFeedThree" class="instagram-carousel">
								</div>
							</div>
						</div>

						<!--=======  End of instagram image container  =======-->
					</div>

					<!--=====  End of instagram image slider  ======-->
				</div>
				<div class="col-lg-4 order-1 order-lg-2">
					<!--=======  instagram intro  =======-->

					<div
						class="instagram-section-intro pl-50 pl-lg-50 pl-md-0 pl-sm-0 pl-xs-0 pl-xxs-0 mb-0 mb-lg-0 mb-md-50 mb-sm-50 mb-xs-50 mb-xxs-50">
						<p><a href="#">@lezada_shop</a></p>
						<h3>Follow us on Instagram</h3>
					</div>

					<!--=======  End of instagram intro  =======-->
				</div>
			</div>
		</div>
	</div>

	<!--=====  End of instagram slider area  ======-->

	<!--=============================================
	=            footer area         =
	=============================================-->

	<div class="footer-container footer-one pt-100 pb-50">
		<div class="container wide">
			<div class="row">
				<div class="col footer-single-widget">
					<!--=======  copyright text  =======-->
					<!--=======  logo  =======-->

					<div class="logo">
						<img src="assets/images/logo.png" class="img-fluid" alt="">
					</div>

					<!--=======  End of logo  =======-->

					<!--=======  copyright text  =======-->

					<div class="copyright-text">
						<p> &copy; 2020 lezada. <span>All Rights Reserved</span></p>
					</div>

					<!--=======  End of copyright text  =======-->

					<!--=======  End of copyright text  =======-->
				</div>
				<div class="col footer-single-widget">
					<!--=======  single widget  =======-->
					<h5 class="widget-title">ABOUT</h5>

					<!--=======  footer navigation container  =======-->

					<div class="footer-nav-container">
						<nav>
							<ul>
								<li><a href="#">About us</a></li>
								<li><a href="#">Store location</a></li>
								<li><a href="#">Contact</a></li>
								<li><a href="#">Orders tracking</a></li>
							</ul>
						</nav>
					</div>

					<!--=======  End of footer navigation container  =======-->

					<!--=======  single widget  =======-->
				</div>
				<div class="col footer-single-widget">
					<!--=======  single widget  =======-->
					<h5 class="widget-title">USEFUL LINKS</h5>

					<!--=======  footer navigation container  =======-->

					<div class="footer-nav-container">
						<nav>
							<ul>
								<li><a href="#">Returns</a></li>
								<li><a href="#">Support Policy</a></li>
								<li><a href="#">Size guide</a></li>
								<li><a href="#">FAQs</a></li>
							</ul>
						</nav>
					</div>

					<!--=======  End of footer navigation container  =======-->

					<!--=======  single widget  =======-->
				</div>

				<div class="col footer-single-widget">
					<!--=======  single widget  =======-->
					<h5 class="widget-title">FOLLOW US ON</h5>

					<!--=======  footer navigation container  =======-->

					<div class="footer-nav-container footer-social-links">
						<nav>
							<ul>
								<li><a href="http://twitter.com/"><i class="fa fa-twitter"></i> Twitter</a></li>
								<li><a href="http://facebook.com/"> <i class="fa fa-facebook"></i> Facebook</a></li>
								<li><a href="http://instagram.com/"><i class="fa fa-instagram"></i> Instagram</a></li>
								<li><a href="http://youtube.com/"> <i class="fa fa-youtube"></i> Youtube</a></li>
							</ul>
						</nav>
					</div>

					<!--=======  End of footer navigation container  =======-->


					<!--=======  single widget  =======-->
				</div>
				<div class="col footer-single-widget">
					<!--=======  single widget  =======-->

					<div class="footer-subscription-widget">
						<h2 class="footer-subscription-title">Subscribe.</h2>
						<p class="subscription-subtitle">Subscribe to our newsletter to receive news on update.</p>

						<!--=======  subscription form  =======-->

						<div class="subscription-form">
							<form id="mc-form" class="mc-form">
								<input type="email" placeholder="Your email address" required>
								<button type="submit"><i class="ion-ios-arrow-thin-right"></i></button>
							</form>
						</div>

						<!--=======  End of subscription form  =======-->

						<!-- mailchimp-alerts Start -->

						<div class="mailchimp-alerts">
							<div class="mailchimp-submitting"></div><!-- mailchimp-submitting end -->
							<div class="mailchimp-success"></div><!-- mailchimp-success end -->
							<div class="mailchimp-error"></div><!-- mailchimp-error end -->
						</div><!-- mailchimp-alerts end -->

					</div>

					<!--=======  End of single widget  =======-->
				</div>
			</div>
		</div>
	</div>

	<!--=====  End of footer area  ======-->


	<!--=============================================
	=            overlay items         =
	=============================================-->

	<!--=======  about overlay  =======-->

	<div class="header-offcanvas about-overlay" id="about-overlay">
		<div class="overlay-close inactive"></div>
		<div class="overlay-content">

			<!--=======  close icon  =======-->

			<span class="close-icon" id="about-close-icon">
				<a href="javascript:void(0)">
					<i class="ti-close"></i>
				</a>
			</span>

			<!--=======  End of close icon  =======-->

			<!--=======  overlay content container  =======-->

			<div class="overlay-content-container d-flex flex-column justify-content-between h-100">
				<!--=======  widget wrapper  =======-->

				<div class="widget-wrapper">
					<!--=======  single widget  =======-->

					<div class="single-widget">
						<h2 class="widget-title">About Us</h2>
						<p>At Lezada, we put a strong emphasis on simplicity, quality and usefulness of fashion products over other
							factors. Our fashion items never get outdated. They are not short-lived as normal fashion clothes.</p>
					</div>

					<!--=======  End of single widget  =======-->
				</div>

				<!--=======  End of widget wrapper  =======-->

				<!--=======  contact widget  =======-->

				<div class="contact-widget">
					<p class="email"><a href="mailto:contact@lezada.com">contact@lezada.com</a></p>
					<p class="phone">(+00) 123 567990</p>

					<div class="social-icons">
						<ul>
							<li><a href="http://www.twitter.com/" data-tippy="Twitter" data-tippy-inertia="true"
									data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true" target="_blank"><i
										class="fa fa-twitter"></i></a></li>
							<li><a href="http://www.facebook.com/" data-tippy="Facebook" data-tippy-inertia="true"
									data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true" target="_blank"><i
										class="fa fa-facebook"></i></a></li>
							<li><a href="http://www.instagram.com/" data-tippy="Instagram" data-tippy-inertia="true"
									data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true" target="_blank"><i
										class="fa fa-instagram"></i></a></li>
							<li><a href="http://www.youtube.com/" data-tippy="Youtube" data-tippy-inertia="true"
									data-tippy-animation="shift-away" data-tippy-delay="50" data-tippy-arrow="true" target="_blank"><i
										class="fa fa-youtube-play"></i></a></li>
						</ul>
					</div>
				</div>

				<!--=======  End of contact widget  =======-->
			</div>

			<!--=======  End of overlay content container  =======-->
		</div>
	</div>

	<!--=======  End of about overlay  =======-->

	<!--=======  wishlist overlay  =======-->

	<div class="wishlist-overlay" id="wishlist-overlay">
		<div class="wishlist-overlay-close inactive"></div>
		<div class="wishlist-overlay-content">
			<!--=======  close icon  =======-->

			<span class="close-icon" id="wishlist-close-icon">
				<a href="javascript:void(0)">
					<i class="ion-android-close"></i>
				</a>
			</span>

			<!--=======  End of close icon  =======-->

			<!--=======  offcanvas wishlist content container  =======-->

			<div class="offcanvas-cart-content-container">
				<h3 class="cart-title">Wishlist</h3>

				<div class="cart-product-wrapper">
					<div class="cart-product-container  ps-scroll">
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/01.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dark Brown Leather Watch</a></h5>
								<p><span class="main-price discounted">$200.00</span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/02.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dining Chair</a></h5>
								<p><span class="main-price discounted">$300.00</span> <span class="discounted-price">$220.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/03.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Creative Wooden Stand</a></h5>
								<p><span class="main-price discounted">$100.00</span> <span class="discounted-price">$80.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/01.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dark Brown Leather Watch</a></h5>
								<p><span class="main-price discounted">$200.00</span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/02.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Creative Wooden Stand</a></h5>
								<p><span class="main-price discounted">$200.00</span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
					</div>

					<!--=======  cart buttons  =======-->

					<div class="cart-buttons">
						<a href="shop-wishlist.html">view wishlist</a>
					</div>

					<!--=======  End of cart buttons  =======-->
				</div>
			</div>

			<!--=======  End of offcanvas wishlist content container   =======-->
		</div>
	</div>

	<!--=======  End of wishlist overlay  =======-->

	<!--=======  cart overlay  =======-->

	<div class="cart-overlay" id="cart-overlay">
		<div class="cart-overlay-close inactive"></div>
		<div class="cart-overlay-content">
			<!--=======  close icon  =======-->

			<span class="close-icon" id="cart-close-icon">
				<a href="javascript:void(0)">
					<i class="ion-android-close"></i>
				</a>
			</span>

			<!--=======  End of close icon  =======-->

			<!--=======  offcanvas cart content container  =======-->

			<div class="offcanvas-cart-content-container">
				<h3 class="cart-title">Cart</h3>

				<div class="cart-product-wrapper">
					<div class="cart-product-container  ps-scroll">
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/01.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dark Brown Leather Watch</a></h5>
								<p><span class="cart-count">2 x </span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/02.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dining Chair</a></h5>
								<p><span class="cart-count">2 x </span> <span class="discounted-price">$220.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/03.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Creative Wooden Stand</a></h5>
								<p><span class="cart-count">2 x </span> <span class="discounted-price">$80.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/01.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Dark Brown Leather Watch</a></h5>
								<p><span class="cart-count">2 x </span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
						<!--=======  single cart product  =======-->

						<div class="single-cart-product">
							<span class="cart-close-icon">
								<a href="#"><i class="ti-close"></i></a>
							</span>
							<div class="image">
								<a href="shop-product-basic.html">
									<img src="assets/images/cart-product-image/02.jpg" class="img-fluid" alt="">
								</a>
							</div>
							<div class="content">
								<h5><a href="shop-product-basic.html">Creative Wooden Stand</a></h5>
								<p><span class="cart-count">2 x </span> <span class="discounted-price">$180.00</span></p>

							</div>
						</div>

						<!--=======  End of single cart product  =======-->
					</div>

					<!--=======  subtotal calculation  =======-->

					<p class="cart-subtotal">
						<span class="subtotal-title">Subtotal:</span>
						<span class="subtotal-amount">$200.00</span>
					</p>

					<!--=======  End of subtotal calculation  =======-->

					<!--=======  cart buttons  =======-->

					<div class="cart-buttons">
						<a href="shop-cart.html">view cart</a>
						<a href="shop-checkout.html">checkout</a>
					</div>

					<!--=======  End of cart buttons  =======-->

					<!--=======  free shipping text  =======-->

					<p class="free-shipping-text">
						Free Shipping on All Orders Over $100!
					</p>

					<!--=======  End of free shipping text  =======-->
				</div>
			</div>

			<!--=======  End of offcanvas cart content container   =======-->
		</div>
	</div>

	<!--=======  End of cart overlay  =======-->


	<!--=======  search overlay  =======-->

	<div class="search-overlay" id="search-overlay">

		<!--=======  close icon  =======-->

		<span class="close-icon search-close-icon">
			<a href="javascript:void(0)" id="search-close-icon">
				<i class="ti-close"></i>
			</a>
		</span>

		<!--=======  End of close icon  =======-->

		<!--=======  search overlay content  =======-->

		<div class="search-overlay-content">
			<div class="input-box">
				<form action="https://live.hasthemes.com/html/3/lezada-preview/lezada/index.html">
					<input type="search" placeholder="Search Products...">
				</form>
			</div>
			<div class="search-hint">
				<span># Hit enter to search or ESC to close</span>
			</div>
		</div>

		<!--=======  End of search overlay content  =======-->
	</div>

	<!--=======  End of search overlay  =======-->

	<!--=====  End of overlay items  ======-->

	<!--=============================================
	=            quick view         =
	=============================================-->

	<div id="qv-1" class="cd-quick-view">
		<div class="cd-slider-wrapper">
			<ul class="cd-slider">
				<li class="selected"><img src="assets/images/products/product-instagram-19-600x800.jpg" alt="Product 2"></li>
				<li><img src="assets/images/products/product-instagram-18-600x800.jpg" alt="Product 1"></li>
			</ul> <!-- cd-slider -->

			<ul class="cd-slider-pagination">
				<li class="active"><a href="#0">1</a></li>
				<li><a href="#1">2</a></li>
			</ul> <!-- cd-slider-pagination -->

			<ul class="cd-slider-navigation">
				<li><a class="cd-prev" href="#0">Prev</a></li>
				<li><a class="cd-next" href="#0">Next</a></li>
			</ul> <!-- cd-slider-navigation -->
		</div> <!-- cd-slider-wrapper -->

		<div class="lezada-item-info cd-item-info ps-scroll">

			<h2 class="item-title">Jesmine green tea</h2>
			<p class="price">
				<span class="main-price discounted">$360.00</span>
				<span class="discounted-price">$300.00</span>
			</p>

			<p class="description">Hurley Dry-Fit Chino Short. Men's chino short. Outseam Length: 19 Dri-FIT Technology helps
				keep you dry and comfortable. Made with sweat-wicking fabric. Fitted waist with belt loops. Button waist with
				zip fly provides a classic look and feel .</p>

			<span class="quickview-title">Quantity:</span>
			<div class="pro-qty d-inline-block mb-40">
				<input type="text" value="1">
			</div>

			<div class="add-to-cart-btn mb-25">

				<button class="lezada-button lezada-button--medium">add to cart</button>
			</div>

			<div class="quick-view-other-info">
				<table>
					<tr class="single-info">
						<td class="quickview-title">SKU: </td>
						<td class="quickview-value">12345</td>
					</tr>
					<tr class="single-info">
						<td class="quickview-title">Categories: </td>
						<td class="quickview-value">
							<a href="#">Fashion</a>,
							<a href="#">Men</a>,
							<a href="#">Sunglasses</a>
						</td>
					</tr>
					<tr class="single-info">
						<td class="quickview-title">Tags: </td>
						<td class="quickview-value">
							<a href="#">Fashion</a>,
							<a href="#">Men</a>
						</td>
					</tr>
					<tr class="single-info">
						<td class="quickview-title">Share on: </td>
						<td class="quickview-value">
							<ul class="quickview-social-icons">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-pinterest"></i></a></li>
							</ul>
						</td>
					</tr>
				</table>
			</div>


		</div> <!-- cd-item-info -->
		<a href="#0" class="cd-close">Close</a>
	</div>

	<!--=====  End of quick view  ======-->

	<!-- scroll to top  -->
	<a href="#" class="scroll-top"></a>
	<!-- end of scroll to top -->

	<!-- JS
	============================================ -->
	<!-- jQuery JS -->
	<script src="<?php base_url();?>assets/js/vendor/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="<?php base_url();?>assets/js/popper.min.js"></script>

	<!-- Bootstrap JS -->
	<script src="<?php base_url();?>assets/js/bootstrap.min.js"></script>

	<!-- Plugins JS -->
	<script src="<?php base_url();?>assets/js/plugins.js"></script>

	<!-- Main JS -->
	<script src="<?php base_url();?>assets/js/main.js"></script>

	<!-- Revolution Slider JS -->
	<script src="<?php base_url();?>assets/revolution/js/jquery.themepunch.revolution.min.js"></script>
	<script src="<?php base_url();?>assets/revolution/js/jquery.themepunch.tools.min.js"></script>
	<script src="<?php base_url();?>assets/revolution/revolution-active.js"></script>

	<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
	<script type="text/javascript" src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script type="text/javascript" src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script type="text/javascript" src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.actions.min.js"></script>
	<script type="text/javascript"
		src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script type="text/javascript" src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
	<script type="text/javascript" src="<?php base_url();?>assets/revolution/js/extensions/revolution.extension.parallax.min.js"></script>


</body>


<!-- Mirrored from live.hasthemes.com/html/3/lezada-preview/lezada/index-cosmetics.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Sep 2020 03:29:28 GMT -->
</html>