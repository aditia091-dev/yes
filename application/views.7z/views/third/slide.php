
<body>

	<!--=============================================
    =            slider area         =
    =============================================-->

	<div class="slider-area header-bottom-slider-area">
		<div id="rev_slider_16_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container" data-alias="homepage-14"
			data-source="gallery"
			style="margin:0px auto;background:transparent;padding:0px;margin-top:0px;margin-bottom:0px;">
			<!-- START REVOLUTION SLIDER 5.4.7 auto mode -->
			<div id="rev_slider_16_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.4.7">
				<ul>
					<!-- SLIDE  -->
					<li data-index="rs-42"
						data-transition="parallaxtoright,parallaxtoleft,parallaxtotop,parallaxtobottom,parallaxhorizontal,parallaxvertical,fadefromright,fadefromleft,fadefromtop,fadefrombottom"
						data-slotamount="default,default,default,default,default,default,default,default,default,default"
						data-hideafterloop="0" data-hideslideonmobile="off"
						data-easein="default,default,default,default,default,default,default,default,default,default"
						data-easeout="default,default,default,default,default,default,default,default,default,default"
						data-masterspeed="700,default,default,default,default,default,default,default,default,default" data-thumb=""
						data-rotate="0,0,0,0,0,0,0,0,0,0" data-saveperformance="off" data-title="Slide" data-param1=""
						data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8=""
						data-param9="" data-param10="" data-description="">
						<!-- MAIN IMAGE -->
						<img src="<?php base_url();?>assets/images/mf/slide/tampak depan-01.png" data-bgcolor='#f8f8f8' style='background:#f8f8f8' alt=""
							data-lazyload="<?php base_url();?>assets/images/mf/slide/tampak depan-01.png" data-bgposition="center center" data-bgfit="cover"
							data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
						<!-- LAYERS -->

						<!-- LAYER NR. 1 -->
						<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" id="slide-42-layer-23"
							data-x="['left','left','left','left']" data-hoffset="['532','180','66','28']"
							data-y="['middle','top','middle','middle']" data-voffset="['0','166','0','-3']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":710,"speed":2760,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 5;">
							
						</div>

						<!-- LAYER NR. 2 
						<div class="tp-caption button-under-line rev-btn  tp-resizeme" id="slide-42-layer-20"
							data-x="['left','center','center','left']" data-hoffset="['1197','230','197','265']"
							data-y="['top','top','top','top']" data-voffset="['712','492','489','347']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="button" data-actions='' data-responsive_offset="on"
							data-frames='[{"delay":1100,"speed":1790,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"300","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(211,18,42);bc:rgb(211,18,42);"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[3,3,3,3]" data-paddingleft="[0,0,0,0]"
							style="z-index: 6; white-space: nowrap; letter-spacing: 1px;border-color:rgb(51,51,51);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
							<!--<a class="revslider-button-red" href="shop-left-sidebar.html"> SHOP COLLECTION</a> </div>-->

						<!-- LAYER NR. 3 
						<div class="tp-caption   tp-resizeme" id="slide-42-layer-22" data-x="['left','left','left','left']"
							data-hoffset="['979','501','384','206']" data-y="['top','top','top','top']"
							data-voffset="['488','308','330','233']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":700,"speed":2000,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 7;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['585px','453px','368px','261px']" data-hh="['186px','144px','117px','83px']"
								data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img4.png" data-no-retina> </div>

						<!-- LAYER NR. 4 
						<div class="tp-caption   tp-resizeme" id="slide-42-layer-24" data-x="['left','left','left','left']"
							data-hoffset="['0','0','0','0']" data-y="['bottom','bottom','bottom','bottom']"
							data-voffset="['0','-44','-44','-44']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":1140,"speed":1200,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 8;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['348px','316px','271px','271px']" data-hh="['195px','177px','152px','152px']"
								data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img3.png" data-no-retina> </div>

						<!-- LAYER NR. 5 
						<div class="tp-caption   tp-resizeme" id="slide-42-layer-25" data-x="['right','right','right','right']"
							data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']"
							data-width="none" data-height="none" data-whitespace="nowrap" data-type="image"
							data-responsive_offset="on"
							data-frames='[{"delay":1820,"speed":1200,"frame":"0","from":"opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 9;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['345px','239px','201px','152px']" data-hh="['281px','195px','164px','124px']"
								data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img2.png" data-no-retina> </div>
					</li>
					<!-- SLIDE  
					<li data-index="rs-43"
						data-transition="slotslide-horizontal,slotslide-vertical,slotfade-horizontal,slidingoverlayup,slidingoverlaydown,slidingoverlayright,slidingoverlayleft"
						data-slotamount="default,default,default,default,default,default,default" data-hideafterloop="0"
						data-hideslideonmobile="off" data-easein="default,default,default,default,default,default,default"
						data-easeout="default,default,default,default,default,default,default"
						data-masterspeed="700,default,default,default,default,default,default"
						data-thumb="assets/images/revimages/cosmetics/100x50_home14-slider2-bg.png" data-rotate="0,0,0,0,0,0,0"
						data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4=""
						data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10=""
						data-description="">
						<!-- MAIN IMAGE 
						<img src="assets/images/revimages/dummy.png" alt=""
							data-lazyload="assets/images/revimages/cosmetics/home14-slider2-bg.png" data-bgposition="center center"
							data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
						<!-- LAYERS -->

						<!-- LAYER NR. 6 
						<div class="tp-caption   tp-resizeme" id="slide-43-layer-27" data-x="['left','left','left','left']"
							data-hoffset="['192','192','192','192']" data-y="['bottom','bottom','bottom','bottom']"
							data-voffset="['0','0','0','0']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":760,"speed":1880,"frame":"0","from":"y:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 5;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['294px','294px','294px','294px']" data-hh="['176px','176px','176px','176px']"
								data-lazyload="assets/images/revimages/cosmetics/home14-slider2-element-2.png" data-no-retina> </div>

						<!-- LAYER NR. 7 
						<div class="tp-caption   tp-resizeme" id="slide-43-layer-28" data-x="['left','left','left','left']"
							data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']"
							data-width="none" data-height="none" data-whitespace="nowrap" data-type="image"
							data-responsive_offset="on"
							data-frames='[{"delay":970,"speed":1890,"frame":"0","from":"y:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 6;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['174px','174px','174px','174px']" data-hh="['129px','129px','129px','129px']"
								data-lazyload="assets/images/revimages/cosmetics/home14-slider2-element-3.png" data-no-retina> </div>

						<!-- LAYER NR. 8 
						<div class="tp-caption   tp-resizeme" id="slide-43-layer-29" data-x="['right','right','right','right']"
							data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']"
							data-width="none" data-height="none" data-whitespace="nowrap" data-type="image"
							data-responsive_offset="on"
							data-frames='[{"delay":1160,"speed":1890,"frame":"0","from":"x:50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 7;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['268px','268px','268px','132px']" data-hh="['1218px','1218px','1218px','600px']"
								data-lazyload="assets/images/revimages/cosmetics/home14-slider2-element-4.png" data-no-retina> </div>

						<!-- LAYER NR. 9 
						<div class="tp-caption   tp-resizeme" id="slide-43-layer-25" data-x="['left','left','center','center']"
							data-hoffset="['1119','590','1','1']" data-y="['top','top','top','top']"
							data-voffset="['426','286','141','141']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="text" data-responsive_offset="on"
							data-frames='[{"delay":690,"speed":1540,"frame":"0","from":"y:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 8; white-space: nowrap; font-size: 18px; line-height: 36px; font-weight: 400; color: #333333; letter-spacing: 0px;font-family:Work Sans;">
							Free delivery from $30 </div>

						<!-- LAYER NR. 10 
						<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" id="slide-43-layer-23"
							data-x="['left','left','left','left']" data-hoffset="['248','43','123','53']"
							data-y="['middle','top','middle','middle']" data-voffset="['-12','45','124','126']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":710,"speed":2760,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 9;">
							<div class="rs-looped rs-slideloop" data-easing="" data-speed="2" data-xs="0" data-xe="0" data-ys="0"
								data-ye="20"><img src="assets/images/revimages/dummy.png" alt=""
									data-ww="['661px','564auto','564auto','386px']" data-hh="['863px','736px','736px','504px']"
									data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img5-1.png" data-no-retina> </div>
						</div>

						<!-- LAYER NR. 11 
						<div class="tp-caption button-under-line rev-btn  tp-resizeme" id="slide-43-layer-20"
							data-x="['left','center','center','left']" data-hoffset="['1152','176','-3','167']"
							data-y="['top','top','top','top']" data-voffset="['677','481','296','276']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="button" data-actions='' data-responsive_offset="on"
							data-frames='[{"delay":950,"speed":1790,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"300","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(211,18,42);bc:rgb(211,18,42);"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[3,3,3,3]" data-paddingleft="[0,0,0,0]"
							style="z-index: 10; white-space: nowrap; letter-spacing: 1px;border-color:rgb(51,51,51);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
							<a class="revslider-button-red" href="shop-left-sidebar.html"> SHOP COLLECTION</a> </div>

						<!-- LAYER NR. 12 
						<div class="tp-caption   tp-resizeme" id="slide-43-layer-22" data-x="['left','left','center','center']"
							data-hoffset="['870','435','0','0']" data-y="['top','top','top','top']"
							data-voffset="['513','357','195','184']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":700,"speed":1330,"frame":"0","from":"y:-50px;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 11;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['684px','499px','447px','384px']" data-hh="['107px','78px','70px','60px']"
								data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img7.png" data-no-retina> </div>
					</li>
					<!-- SLIDE  
					<li data-index="rs-44"
						data-transition="fadefromright,fadefromleft,fadefromtop,fadefrombottom,fadetoleftfadefromright,fadetorightfadefromleft,fadetotopfadefrombottom,fadetobottomfadefromtop,curtain-1,curtain-2,curtain-3"
						data-slotamount="default,default,default,default,default,default,default,default,default,default,default"
						data-hideafterloop="0" data-hideslideonmobile="off"
						data-easein="default,default,default,default,default,default,default,default,default,default,default"
						data-easeout="default,default,default,default,default,default,default,default,default,default,default"
						data-masterspeed="700,default,default,default,default,default,default,default,default,default,default"
						data-thumb="" data-rotate="0,0,0,0,0,0,0,0,0,0,0" data-saveperformance="off" data-title="Slide"
						data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7=""
						data-param8="" data-param9="" data-param10="" data-description="">
						<!-- MAIN IMAGE 
						<img src="assets/images/revimages/dummy.png" data-bgcolor='#f9f0ee' style='background:#f9f0ee' alt=""
							data-lazyload="assets/images/revimages/transparent.png" data-bgposition="center center" data-bgfit="cover"
							data-bgrepeat="no-repeat" data-bgparallax="off" class="rev-slidebg" data-no-retina>
						<!-- LAYERS -->

						<!-- LAYER NR. 13 
						<div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme" id="slide-44-layer-27"
							data-x="['left','left','left','left']" data-hoffset="['285','40','193','111']"
							data-y="['top','top','top','top']" data-voffset="['174','103','411','394']"
							data-width="['620','493','417','279']" data-height="['620','493','417','279']" data-whitespace="nowrap"
							data-type="shape" data-responsive_offset="on"
							data-frames='[{"delay":680,"speed":1000,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power2.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 5;background-color:rgb(255,255,255);border-radius:100% 100% 100% 100%;"> </div>

						<!-- LAYER NR. 14 
						<div class="tp-caption   tp-resizeme" id="slide-44-layer-25" data-x="['left','left','center','center']"
							data-hoffset="['1258','634','0','9']" data-y="['top','top','top','top']"
							data-voffset="['361','213','113','127']" data-fontsize="['18','18','18','14']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
							data-frames='[{"delay":690,"speed":1540,"frame":"0","from":"y:-50px;opacity:0;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 6; white-space: nowrap; font-size: 18px; line-height: 36px; font-weight: 400; color: #333333; letter-spacing: 0px;font-family:Work Sans;">
							Free delivery from $30 </div>

						<!-- LAYER NR. 15 -
						<div class="tp-caption   tp-resizeme rs-parallaxlevel-1" id="slide-44-layer-23"
							data-x="['left','left','left','left']" data-hoffset="['345','68','207','130']"
							data-y="['middle','top','middle','middle']" data-voffset="['0','77','239','201']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":1220,"speed":2760,"frame":"0","from":"z:0;rX:0;rY:0;rZ:0;sX:0.8;sY:0.8;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power4.easeOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 7;">
							<div class="rs-looped rs-slideloop" data-easing="" data-speed="2" data-xs="0" data-xe="0" data-ys="0"
								data-ye="20"><img src="assets/images/revimages/dummy.png" alt=""
									data-ww="['491px','440px','396px','251px']" data-hh="['696px','660px','662px','356px']"
									data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img6.png" data-no-retina> </div>
						</div>

						<!-- LAYER NR. 16 -->
						<div class="tp-caption button-under-line rev-btn  tp-resizeme" id="slide-44-layer-20"
							data-x="['left','center','center','left']" data-hoffset="['1291','222','-2','174']"
							data-y="['top','top','top','top']" data-voffset="['718','506','353','331']" data-width="none"
							data-height="none" data-whitespace="nowrap" data-type="button" data-actions='' data-responsive_offset="on"
							data-frames='[{"delay":950,"speed":1790,"frame":"0","from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","to":"o:1;","ease":"Power3.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"},{"frame":"hover","speed":"300","ease":"Linear.easeNone","to":"o:1;rX:0;rY:0;rZ:0;z:0;","style":"c:rgb(211,18,42);bc:rgb(211,18,42);"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[3,3,3,3]" data-paddingleft="[0,0,0,0]"
							style="z-index: 8; white-space: nowrap; letter-spacing: 1px;border-color:rgb(51,51,51);outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">
							<a class="revslider-button-red" href="shop-left-sidebar.html"> SHOP COLLECTION</a></div>

						<!-- LAYER NR. 17 -->
						<div class="tp-caption   tp-resizeme" id="slide-44-layer-22" data-x="['left','left','center','center']"
							data-hoffset="['1095','533','0','17']" data-y="['top','top','top','top']"
							data-voffset="['451','274','165','174']" data-width="none" data-height="none" data-whitespace="nowrap"
							data-type="image" data-responsive_offset="on"
							data-frames='[{"delay":700,"speed":1330,"frame":"0","from":"y:-50px;opacity:0;","to":"o:1;","ease":"Power4.easeInOut"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
							data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]"
							data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"
							style="z-index: 9;"><img src="assets/images/revimages/dummy.png" alt=""
								data-ww="['511auto','454px','390px','297px']" data-hh="['215px','191px','164px','125px']"
								data-lazyload="assets/images/revimages/cosmetics/slider-homepage14-img8.png" data-no-retina> </div>
					</li>
				</ul>
				<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
			</div>
		</div><!-- END REVOLUTION SLIDER -->
	</div>

	<!--=====  End of slider area  ======-->

<br>
		<br>
		<br>