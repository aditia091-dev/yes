<!DOCTYPE html>
<html class="no-js" lang="zxx">


<!-- Mirrored from live.hasthemes.com/html/3/lezada-preview/lezada/index-cosmetics.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 28 Sep 2020 03:28:17 GMT -->
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Lezada - Multipurpose eCommerce Bootstrap4 Template</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Favicon -->
	<link rel="icon" href="assets/images/favicon.ico">

	<!-- CSS
	============================================ -->
	<!-- Bootstrap CSS -->
	<link href="<?php base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">

	<!-- FontAwesome CSS -->
	<link href="<?php base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">

	<!-- Ionicons CSS -->
	<link href="<?php base_url();?>assets/css/ionicons.min.css" rel="stylesheet">

	<!-- Themify CSS -->
	<link href="<?php base_url();?>assets/css/themify-icons.css" rel="stylesheet">

	<!-- Plugins CSS -->
	<link href="<?php base_url();?>assets/css/plugins.css" rel="stylesheet">

	<!-- Helper CSS -->
	<link href="<?php base_url();?>assets/css/helper.css" rel="stylesheet">

	<!-- Main CSS -->
	<link href="<?php base_url();?>assets/css/main.css" rel="stylesheet">

	<!-- Revolution Slider CSS -->
	<link href="<?php base_url();?>assets/revolution/css/settings.css" rel="stylesheet">
	<link href="<?php base_url();?>assets/revolution/css/navigation.css" rel="stylesheet">
	<link href="<?php base_url();?>assets/revolution/custom-setting.css" rel="stylesheet">

	<!-- Modernizer JS -->
	<script src="<?php base_url();?>assets/js/vendor/modernizr-2.8.3.min.js"></script>

</head>
