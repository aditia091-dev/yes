<?php $this->load->view('third/style') ?>
<?php $this->load->view('third/slide') ?>
<?php $this->load->view('third/prod') ?>
<?php $this->load->view('third/content') ?>

<?php $this->load->view('third/footer') ?>